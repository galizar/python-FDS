def cansado(nivel):
    if nivel < 5:
        return 'No seas flojo, anda a trabajar muchacho marico'
    else:
        return 'anda a descansar papi'